module.exports.config = {
    name: "murgi",
    version: "1.0",
    role: 1,
    author: "Mesbah Bb'e",
    description: "5 বারের জন্য ক্রমাগত বন্ধুর ট্যাগ ট্যাগ করুন\nসেই ব্যক্তিকে আত্মা কলিং বলা যেতে পারে",
    category: "nsfw",
    guide: " please @mention",
    coolDown: 10
}
module.exports.onStart = async function({ api, args, Users, event}) {
    var mention = Object.keys(event.mentions)[0];
    if(!mention) return api.sendMessage("জিসান বস খানকির পুলারে একটা মেনশন দে-!!🫂", event.threadID);
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention, tag: name});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a("তোর জিসান আব্বুর চুদা লো");
setTimeout(() => {a({body:"খানকির বাচ্চা তোর মারে চুদি 🫦।" + " " + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "খানকির বাচ্চা তোর কচি বোন রে চুদি 💋.." + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: "মাদারচোদ তোর আম্মুর পম পম খানকির পো 🐰" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: "খানকির বাচ্চা তোর মার  ভুদায় কামর দিমু 🖕!" + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "খানকি মাগির বাচ্চা কথা ক কম কম তোর আম্মু রে চুদে বানামু আইটেম বোম " + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "depression থেকেও তোর মাইরে চু*** দি 🫵🥵 " + " " + name, mentions: arraytag})}, 15000);
setTimeout(() => {a({body: "তোর আম্মু রে আচার এর লোভ দেখিয়ে চুদি নটির বাচ্চা 🤬" + " " + name, mentions: arraytag})}, 17000);
setTimeout(() => {a({body: "বান্দির বাচ্চা তোর কচি বোনের ভুদা ফাক করে থুতু দিয়ে ভুদায় ধোন ডুকামু 🫦" + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: " মাগির বাচ্চা তোর আম্মু রে চুদি তোর দুলা ভাই এর কান্দে ফেলে  🤝" + " " + name, mentions: arraytag})},23000);
setTimeout(() => {a({body: "উফফফ খাদ্দামা মাগির বাচ্চা তোর আম্মুর কালা ভুদায় আমার মাল আউট তোর কচি বোন রে দুই পা উচু করে এবার চুদবো  💉।" + " " + name, mentions: arraytag})}, 25000);
setTimeout(() => {a({body: "অনলাইনে গালি বাজ হয়ে গেছো মাগির বাচ্চা এমন চুদা দিমু লাইফ টাইম মনে রাখবি আমার বস তোর বাপ নটির বাচ্চা 🤬।" + " " + name, mentions: arraytag})}, 28500);
setTimeout(() => {a({body: "ভাতিজা শুন তোর আম্মু রে চুদলে রাগ করবি না তো, আচ্ছা যা রাগ করিস না তোর আম্মুর কালা ভুদা আর চুদলাম না তোর বোন এর জামা টা খুলে দে  😋" + " " + name, mentions: arraytag})},31000);
setTimeout(() => {a({body: " হাই মাদারচোদ তোর কচি বোন কে আদর করে করে চুদি " + " " + name, mentions: arraytag})}, 36000);
setTimeout(() => {a("~ চুদা কি আরো খাবি মাগির বাচ্চা 🤖")} , 39000);
setTimeout(() => {a({body: "খাংকির বাচ্চা 🥰।" + " " + name, mentions: arraytag})}, 42000);
setTimeout(() => {a({body: "মাদারচোদ😍.." + " " + name, mentions: arraytag})}, 48000);
setTimeout(() => {a({body: "নটির বাচ্চা 🐰" + " " + name, mentions: arraytag})}, 51000);
setTimeout(() => {a({body: " খানকি মাগির বাচ্চা  💔!" + " " + name, mentions: arraytag})}, 54000);
setTimeout(() => {a({body: "পতিতা মাগির বাচ্চা " + " " + name, mentions: arraytag})}, 57000);
setTimeout(() => {a({body: "depression থেকেও তোর বোন কে চু*** দি 🤬 " + " " + name, mentions: arraytag})}, 59400);
setTimeout(() => {a({body: "তোর মারে চুদি" + " " + name, mentions: arraytag})}, 63000);
setTimeout(() => {a({body: "নাট বল্টু মাগির বাচ্চা🫵" + " " + name, mentions: arraytag})}, 66000);
setTimeout(() => {a({body: "তোর বোন কে পায়জামা খুলে চুদি 🤣" + " " + name, mentions: arraytag})},69000);
setTimeout(() => {a({body: "উম্মম্মা তোর বোন এর কচি ভুদায় 💋।" + " " + name, mentions: arraytag})}, 72000);
setTimeout(() => {a({body: "DNA টেষ্ট কইরা দেখবি আমার বস এর  চুদা তেই তোর জন্ম।" + " " + name, mentions: arraytag})}, 75000);
setTimeout(() => {a({body: "কামলা মাগির বাচ্চা  🤣" + " " + name, mentions: arraytag})},81000);
setTimeout(() => {a({body: " বাস্ট্রাড এর বাচ্চা বস্তিতে জন্ম তোর 🫵 " + " " + name, mentions: arraytag})}, 87000);
setTimeout(() => {a("~ আমার বস এর জারজ শন্তান 😜")} , 93000);
setTimeout(() => {a({body: "Welcome মাগির বাচ্চা 🫦।" + " " + name, mentions: arraytag})}, 99000);
setTimeout(() => {a({body: "তোর কচি বোন এর পম পম 💋.." + " " + name, mentions: arraytag})}, 105000);
setTimeout(() => {a({body: "নটির বাচ্চা কথা শুন তোর আম্মু রে চুদি গামছা পেচিয়ে🐰" + " " + name, mentions: arraytag})}, 111000);
setTimeout(() => {a({body: "Hi আমার বস এর জারজ শন্তান মাগির বাচ্চা 🤣!" + " " + name, mentions: arraytag})}, 114000);
setTimeout(() => {a({body: "২০ টাকার পতিতা মাগির বাচ্চা 😝 " + " " + name, mentions: arraytag})}, 120000);
setTimeout(() => {a({body: "depression থেকেও তোর মাইরে চু*** দি 🫦🖕 " + " " + name, mentions: arraytag})}, 126000);
setTimeout(() => {a({body: "বস্তিতে জন্ম অনলাইনে ভাব চুদাও এমন চুদা চুদবো তোর মা,বোন এর পুটকির তার ছিড়ে যাবে  👻" + " " + name, mentions: arraytag})}, 132000);
setTimeout(() => {a({body: "টুকাই মাগির বাচ্চা 🖕" + " " + name, mentions: arraytag})}, 138000);
setTimeout(() => {a({body: "তোর আম্মু রে পায়জামা খুলে চুদি 🤣" + " " + name, mentions: arraytag})},144000);
setTimeout(() => {a({body: "উম্মম্মা তোর বোন এর কচি ভুদায় 💋🫦।" + " " + name, mentions: arraytag})}, 150000);
setTimeout(() => {a({body: "উম্মম্মা তোর বোন এর পম পম খাইতেছি আহ্ শান্তি৷ 😋।" + " " + name, mentions: arraytag})}, 156000);
setTimeout(() => {a({body: "হিজলা মাগির বাচ্চা 🫵" + " " + name, mentions: arraytag})},162000);
setTimeout(() => {a({body: " বস্তির দালাল এর বাচ্চা বস্তিতে তোর জন্ম " + " " + name, mentions: arraytag})}, 168000);
setTimeout(() => {a("~ আমার জারজ শন্তান যা ভাগ 🤣")} , 171000);
setTimeout(() => {a({body: "Welcome শুয়োরের বাচ্চা 🥰।" + " " + name, mentions: arraytag})}, 174000);
setTimeout(() => {a({body: "কুত্তার বাচ্চা তোর কচি বোন এর পম পম 💋😋.." + " " + name, mentions: arraytag})}, 177000);
setTimeout(() => {a({body: "খানকির বাচ্চা কথা শুন তোর বোন রে চুদি গামছা পেচিয়ে 🫦" + " " + name, mentions: arraytag})}, 180000);
setTimeout(() => {a({body: "খানকির বাচ্চা দেখ তোর বোন কে চুদি তোর বোন আহ্, আহ্, উহ্ করছে 🤣!" + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "খানকি  মাগির বাচ্চা " + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "তোর বাপ তোর নানা হয় কুত্তার বচ্চা। 🤬 " + " " + name, mentions: arraytag})}, 15000);
setTimeout(() => {a({body: "নটির বচ্চা তোর বোনরে মুসলমানি দিমু 😜।" + " " + name, mentions: arraytag})}, 17000);
setTimeout(() => {a({body: "টুকাই মাগির বাচ্চা মোবাইল ভাইব্রেশন কইরা তোর কচি বোন এর ভুদার ভিতরে ঢুকিয়ে দিবো 👻" + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: "তোর মুখে হাইগা দিমু। 🤣" + " " + name, mentions: arraytag})},23000);
setTimeout(() => {a({body: "কুত্তার পুকটি চাটামু💉।" + " " + name, mentions: arraytag})}, 25000);
setTimeout(() => {a({body: "তোর আম্মুর হোগা দিয়া ট্রেন ভইরা দিমু।।" + " " + name, mentions: arraytag})}, 28500);
setTimeout(() => {a({body: "হিজলা মাগির বাচ্চা হাতির ধোন দিয়া তোর মায়েরে চুদুম।  😁" + " " + name, mentions: arraytag})},31000);
setTimeout(() => {a({body: "তোর বোন এর ভোদা ছিল্লা লবণ লাগায় দিমু। 😝" + " " + name, mentions: arraytag})}, 36000);
setTimeout(() => {a("~ আমার ফাটা কন্ডমের ফসল। যা ভাগ 🫵")} , 39000);
setTimeout(() => {a({body: "Welcome শুয়োরের বাচ্চা 🥒।" + " " + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "কুত্তার বাচ্চা তোর বোনের ভোদায় মাগুর মাছ চাষ করুম।🍌.." + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: "খানকির বাচ্চা তোর বোনের পিছনে ইনপুট, তোর মায়ের ভোদায় আউটপুট।🐰" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: "তোর মায়ের ভোদা বোম্বাই মরিচ দিয়া চুদামু। 🌶!" + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "খানকি মাগির বাচ্চা তোর মায়ের ভোদা শিরিষ কাগজ দিয়া ঘইষা দিমু। " + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "জং ধরা লোহা দিয়া পাকিস্তানের মানচিত্র বানাই্য়া তোদের পিছন দিয়া ঢুকামু।🤬 " + " " + name, mentions: arraytag})}, 15000);
setTimeout(() => {a({body: "খানকির বাচ্চা তোর মায়ের ভুদাতে পোকা।" + " " + name, mentions: arraytag})}, 17000);
setTimeout(() => {a({body: "টুকাই মাগির বাচ্চা তোর মার ভোদা পাব্লিক টয়লেট।🍆" + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: "তোর মুখে হাইগ্যা দিমু। ভুস্কি মাগির বাচ্চা 🤣" + " " + name, mentions: arraytag})},23000);
setTimeout(() => {a({body: "কান্দে ফালাইয়া তোর মায়েরে চুদি💉।" + " " + name, mentions: arraytag})}, 25000);
setTimeout(() => {a({body: "তোর আম্মুরে উপ্তা কইরা চুদা দিমু।।" + " " + name, mentions: arraytag})}, 28500);
setTimeout(() => {a({body: "হিজলা মাগির বাচ্চা বালি দিয়া চুদমু তোরে খানকি মাগী!তোর মাকে।  🍌" + " " + name, mentions: arraytag})},31000);
setTimeout(() => {a({body: "তোর বোন এর ভোদায় মধু ঢেলে চেটে চেটে খাবো 🍒। " + " " + name, mentions: arraytag})}, 36000);
setTimeout(() => {a("~ মাগির বাচ্চা। যা ভাগ 🫵")} , 39000);




	}
